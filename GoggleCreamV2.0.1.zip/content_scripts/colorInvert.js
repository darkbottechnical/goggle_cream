document.body.style.filter = 'invert(100%)';
