color = prompt("Pick a background color.");
document.querySelectorAll("*").forEach(el=>{el.style.backgroundColor = color});