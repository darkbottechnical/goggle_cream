document.querySelectorAll('img').forEach(image => {
    image.style.filter = 'grayscale(100%)';
});
