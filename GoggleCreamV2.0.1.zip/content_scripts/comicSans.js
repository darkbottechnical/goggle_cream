document.querySelectorAll('*').forEach(el => {
    el.style.fontFamily = 'Comic Sans MS';
});
